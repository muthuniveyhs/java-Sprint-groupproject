document.getElementById("taskForm").addEventListener("submit", function(e) {
  e.preventDefault();
  let isValid = true;

  const name = document.getElementById("name").value.trim();
  const description = document.getElementById("description").value.trim();
  const assignedTo = document.getElementById("assignedTo").value.trim();
  const dueDate = document.getElementById("dueDate").value;
  const status = document.getElementById("status").value;

  document.querySelectorAll(".text-danger").forEach(el => el.textContent = "");

  if (!name) { document.getElementById("nameError").textContent = "Task name is required"; isValid = false; }
  if (!description) { document.getElementById("descriptionError").textContent = "Description is required"; isValid = false; }
  if (!assignedTo) { document.getElementById("assignedToError").textContent = "Assigned To is required"; isValid = false; }
  if (!dueDate) { document.getElementById("dueDateError").textContent = "Due date is required"; isValid = false; }
  if (!status) { document.getElementById("statusError").textContent = "Status is required"; isValid = false; }

  if (!isValid) return;

  const taskCard = document.createElement("div");
  taskCard.className = "list-group-item card mb-2";
  taskCard.innerHTML = `<div class="card-body">
    <h5 class="card-title">${name}</h5>
    <p>${description}</p>
    <p>Assigned To: ${assignedTo}</p>
    <p>Due Date: ${dueDate}</p>
    <span class="badge bg-primary">${status}</span>
  </div>`;

  document.getElementById("taskList").appendChild(taskCard);
  document.getElementById("taskForm").reset();
});